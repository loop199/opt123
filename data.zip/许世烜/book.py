import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors
from surprise import Dataset, Reader, KNNBasic
from surprise.model_selection import train_test_split
import warnings
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from PIL import Image, ImageTk

warnings.filterwarnings('ignore')

# 1. 数据加载与预处理
try:
    books = pd.read_csv('movies_books.csv')
    ratings = pd.read_csv('ratings_books.csv')
    tags = pd.read_csv('tags_books.csv')
    links = pd.read_csv('links_books.csv')
except FileNotFoundError:
    # 如果文件不存在，创建空DataFrame防止程序崩溃
    books = pd.DataFrame(columns=['bookId', 'title', 'categories'])
    ratings = pd.DataFrame(columns=['userId', 'bookId', 'rating'])
    tags = pd.DataFrame(columns=['userId', 'bookId', 'tag'])
    links = pd.DataFrame(columns=['bookId', 'isbn'])

# 重命名列以更符合图书场景
books = books.rename(columns={'title': 'title', 'genres': 'categories'})

# 处理ISBN数据
if 'isbn' in links.columns:
    links['isbn'] = links['isbn'].astype(str).str.split('.').str[0]

# 合并图书信息
if not books.empty and not links.empty:
    books = pd.merge(books, links, on='bookId', how='left')

# 2. 特征工程
if not books.empty:
    tfidf = TfidfVectorizer(stop_words='english')
    books['categories'] = books['categories'].fillna('')
    tfidf_matrix = tfidf.fit_transform(books['categories'])
    cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)
else:
    cosine_sim = np.array([])


# 3. 基于内容的推荐
def get_content_based_recommendations(title, cosine_sim=cosine_sim, books=books):
    try:
        if books.empty or cosine_sim.size == 0:
            return pd.Series([])

        idx = books[books['title'] == title].index[0]
        sim_scores = list(enumerate(cosine_sim[idx]))
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
        sim_scores = sim_scores[1:11]
        book_indices = [i[0] for i in sim_scores]
        return books['title'].iloc[book_indices]
    except (IndexError, KeyError):
        return pd.Series([])


# 4. 协同过滤推荐
if not ratings.empty:
    reader = Reader(rating_scale=(0.5, 5))
    data = Dataset.load_from_df(ratings[['userId', 'bookId', 'rating']], reader)
    trainset, testset = train_test_split(data, test_size=0.25)
    sim_options = {'name': 'cosine', 'user_based': True}
    algo = KNNBasic(sim_options=sim_options)
    algo.fit(trainset)
else:
    algo = None


def get_collaborative_recommendations(user_id, algo=algo, books=books, n_recommendations=10):
    if algo is None or books.empty or ratings.empty:
        return pd.Series([])

    rated_books = ratings[ratings['userId'] == user_id]['bookId'].unique()
    all_books = books['bookId'].unique()
    unrated_books = [book for book in all_books if book not in rated_books]

    predictions = []
    for book in unrated_books:
        pred = algo.predict(user_id, book)
        predictions.append((book, pred.est))

    predictions.sort(key=lambda x: x[1], reverse=True)
    top_n = predictions[:n_recommendations]
    recommended_book_ids = [book[0] for book in top_n]

    return books[books['bookId'].isin(recommended_book_ids)]['title']


# 5. 混合推荐
def hybrid_recommendation(user_id, title, n_recommendations=10):
    content_rec = get_content_based_recommendations(title)
    content_rec_ids = books[books['title'].isin(content_rec)]['bookId'].tolist() if not content_rec.empty else []

    collab_rec = get_collaborative_recommendations(user_id, n_recommendations=n_recommendations)
    collab_rec_ids = books[books['title'].isin(collab_rec)]['bookId'].tolist() if not collab_rec.empty else []

    user_tags = tags[tags['userId'] == user_id]
    tag_rec_ids = user_tags['bookId'].unique().tolist() if not user_tags.empty else []

    hybrid_rec_ids = list(set(content_rec_ids + collab_rec_ids + tag_rec_ids))

    return books[books['bookId'].isin(hybrid_rec_ids)]['title'].head(n_recommendations)


# 6. 评估推荐系统
def evaluate_recommendations():
    if algo is None or books.empty or ratings.empty:
        return "无法评估：数据不足"

    predictions = algo.test(testset)
    rmse = np.sqrt(np.mean([(pred.r_ui - pred.est) ** 2 for pred in predictions]))

    all_books = books['bookId'].unique()
    recommended_books = []
    for user in ratings['userId'].unique()[:100]:
        recs = get_collaborative_recommendations(user, n_recommendations=5)
        recommended_books.extend(books[books['title'].isin(recs)]['bookId'].tolist())

    coverage = len(set(recommended_books)) / len(all_books) if len(all_books) > 0 else 0

    return f"RMSE: {rmse:.4f}\n覆盖率: {coverage:.2%}"


# 创建GUI界面
class BookRecommendationApp:
    def __init__(self, root):
        self.root = root
        self.root.title("图书推荐系统")
        self.root.geometry("800x600")

        # 设置样式
        self.style = ttk.Style()
        self.style.configure('TFrame', background='#f0f0f0')
        self.style.configure('TLabel', background='#f0f0f0', font=('Arial', 10))
        self.style.configure('TButton', font=('Arial', 10))
        self.style.configure('TEntry', font=('Arial', 10))
        self.style.configure('TCombobox', font=('Arial', 10))

        # 创建主框架
        self.main_frame = ttk.Frame(root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 标题
        self.title_label = ttk.Label(self.main_frame, text="图书推荐系统", font=('Arial', 16, 'bold'))
        self.title_label.pack(pady=(0, 20))

        # 输入框架
        self.input_frame = ttk.Frame(self.main_frame)
        self.input_frame.pack(fill=tk.X, pady=5)

        # 用户ID输入
        self.user_id_label = ttk.Label(self.input_frame, text="用户ID:")
        self.user_id_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.user_id_entry = ttk.Entry(self.input_frame)
        self.user_id_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)

        # 喜欢的图书标签
        self.tag_label = ttk.Label(self.input_frame, text="喜欢的标签:")
        self.tag_label.grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.tag_entry = ttk.Entry(self.input_frame)
        self.tag_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)

        # 喜欢的图书标题
        self.book_label = ttk.Label(self.input_frame, text="喜欢的图书标题:")
        self.book_label.grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.book_entry = ttk.Entry(self.input_frame)
        self.book_entry.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)

        # 推荐数量
        self.num_label = ttk.Label(self.input_frame, text="推荐数量:")
        self.num_label.grid(row=3, column=0, padx=5, pady=5, sticky=tk.W)
        self.num_entry = ttk.Entry(self.input_frame)
        self.num_entry.insert(0, "10")  # 默认值
        self.num_entry.grid(row=3, column=1, padx=5, pady=5, sticky=tk.W)

        # 推荐类型
        self.type_label = ttk.Label(self.input_frame, text="推荐类型:")
        self.type_label.grid(row=4, column=0, padx=5, pady=5, sticky=tk.W)
        self.type_var = tk.StringVar()
        self.type_combobox = ttk.Combobox(self.input_frame, textvariable=self.type_var,
                                          values=["基于内容", "协同过滤", "混合推荐"])
        self.type_combobox.current(2)  # 默认选择混合推荐
        self.type_combobox.grid(row=4, column=1, padx=5, pady=5, sticky=tk.W)

        # 按钮框架
        self.button_frame = ttk.Frame(self.main_frame)
        self.button_frame.pack(fill=tk.X, pady=10)

        # 推荐按钮
        self.recommend_button = ttk.Button(self.button_frame, text="获取推荐", command=self.get_recommendations)
        self.recommend_button.pack(side=tk.LEFT, padx=5)

        # 评估按钮
        self.evaluate_button = ttk.Button(self.button_frame, text="评估系统", command=self.evaluate_system)
        self.evaluate_button.pack(side=tk.LEFT, padx=5)

        # 结果输出框架
        self.result_frame = ttk.Frame(self.main_frame)
        self.result_frame.pack(fill=tk.BOTH, expand=True)

        # 结果文本框
        self.result_text = scrolledtext.ScrolledText(self.result_frame, wrap=tk.WORD, font=('Arial', 10))
        self.result_text.pack(fill=tk.BOTH, expand=True)

        # 状态栏
        self.status_var = tk.StringVar()
        self.status_var.set("就绪")
        self.status_bar = ttk.Label(self.main_frame, textvariable=self.status_var, relief=tk.SUNKEN)
        self.status_bar.pack(fill=tk.X, pady=(5, 0))

        # 加载图书标题到自动完成
        self.setup_autocomplete()

    def setup_autocomplete(self):
        if not books.empty:
            book_titles = books['title'].unique().tolist()

            # 简单的自动完成功能
            def autocomplete(event):
                typed = self.book_entry.get()
                if typed:
                    matches = [title for title in book_titles if typed.lower() in title.lower()]
                    if matches:
                        self.book_entry['values'] = matches
                    else:
                        self.book_entry['values'] = []
                else:
                    self.book_entry['values'] = []

            # 将Entry转换为Combobox以实现自动完成
            self.book_entry.destroy()
            self.book_entry = ttk.Combobox(self.input_frame)
            self.book_entry.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)
            self.book_entry.bind('<KeyRelease>', autocomplete)

    def get_recommendations(self):
        try:
            user_id = int(self.user_id_entry.get())
            tag = self.tag_entry.get()
            book_title = self.book_entry.get()
            num_recommendations = int(self.num_entry.get())
            rec_type = self.type_var.get()

            self.result_text.delete(1.0, tk.END)

            # 更新标签数据
            if tag and book_title and not books.empty:
                book_id = books[books['title'] == book_title]['bookId'].values
                if len(book_id) > 0:
                    new_tag = pd.DataFrame({'userId': [user_id], 'bookId': [book_id[0]], 'tag': [tag]})
                    global tags
                    tags = pd.concat([tags, new_tag], ignore_index=True)

            # 根据推荐类型获取推荐
            if rec_type == "基于内容":
                if not book_title:
                    messagebox.showwarning("警告", "基于内容的推荐需要输入喜欢的图书标题")
                    return

                recommendations = get_content_based_recommendations(book_title)
                self.result_text.insert(tk.END, f"基于内容推荐（类似《{book_title}》的图书）：\n\n")

            elif rec_type == "协同过滤":
                recommendations = get_collaborative_recommendations(user_id, n_recommendations=num_recommendations)
                self.result_text.insert(tk.END, f"协同过滤推荐（为用户{user_id}推荐图书）：\n\n")

            else:  # 混合推荐
                if not book_title:
                    messagebox.showwarning("警告", "混合推荐需要输入喜欢的图书标题")
                    return

                recommendations = hybrid_recommendation(user_id, book_title, num_recommendations)
                self.result_text.insert(tk.END, f"混合推荐（为用户{user_id}推荐类似《{book_title}》的图书）：\n\n")

            # 显示推荐结果
            if recommendations.empty:
                self.result_text.insert(tk.END, "没有找到推荐结果。请尝试其他输入。")
            else:
                for i, title in enumerate(recommendations, 1):
                    self.result_text.insert(tk.END, f"{i}. {title}\n")

            self.status_var.set("推荐完成")

        except ValueError as e:
            messagebox.showerror("错误", f"输入错误: {str(e)}")
            self.status_var.set("输入错误")
        except Exception as e:
            messagebox.showerror("错误", f"发生错误: {str(e)}")
            self.status_var.set("错误")

    def evaluate_system(self):
        try:
            evaluation = evaluate_recommendations()
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "系统评估结果:\n\n")
            self.result_text.insert(tk.END, evaluation)
            self.status_var.set("评估完成")
        except Exception as e:
            messagebox.showerror("错误", f"评估失败: {str(e)}")
            self.status_var.set("评估错误")


# 运行应用程序
if __name__ == "__main__":
    root = tk.Tk()
    app = BookRecommendationApp(root)
    root.mainloop()
